#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<netdb.h>
#include<string.h>

struct konfiguracja  //do przechowywania danych z pliku konfiguracyjnego
{
 
 char port[6];
 char lKlientow[3];
};

struct konfiguracja pobierz(char *sciezka) //funkcja pobierajaca dane z pliku konfiguracyjnego
{
 struct konfiguracja konf1;
 FILE *plik;
 int i; 
 plik = fopen(sciezka, "r");
 fgets(konf1.port, sizeof(konf1.port), plik);
 fgets(konf1.lKlientow, sizeof(konf1.lKlientow), plik);
 for(i=0; i<6; i++)
 {
   if(konf1.port[i]=='\n')
   {
      konf1.port[i]='\0';
   }
 }
 close( plik);
 return konf1;
}  

int main(int argc, char **argv)
{
 struct konfiguracja konf1;
 int sockid, sockKlientow; //sockid- deskryptor gniazda serwera, 
 struct sockaddr_in my_addr, thier_addr; //
 struct addrinfo hints, *res, *p; //
 socklen_t sin_size;
 size_t byteread;
 int r; 

 konf1=pobierz("konfiguracja.txt");
 printf("port: %d\nklienty: %d\n", atoi(konf1.port), atoi(konf1.lKlientow));
 
 //sockKlientow = (int*) malloc (sizeof(int)*(atoi(konf1.lKlientow))); //tablica do przechowywania deskryptorow klientow
 
 memset(&hints, 0, sizeof hints);
 hints.ai_family=AF_INET;
 hints.ai_socktype=SOCK_STREAM;

 if((r=getaddrinfo(NULL, konf1.port, &hints, &res)) != 0)
 {
 	printf("getaddrinfo daje dupy\n");
 	exit(1); 
 } 
 
 
for(p = res; p != NULL; p = p->ai_next)
{
 	if((sockid=socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
 	{
   	perror("socket");
   	continue;
 	}
 	if (bind(sockid, p->ai_addr, p->ai_addrlen) == -1)
 	{
   	perror("bind");
  	 	continue;
 	}
 	break;
}

if(p==NULL)
{
 printf("bind failed\n");
 exit(2);
}
//else printf("JEST OK\n");

 if (listen(sockid, atoi(konf1.lKlientow)) == -1)
 {
 	perror("listen");
   exit(1);
 }
 
 while(1)
 {
   sin_size = sizeof(thier_addr);
   	
	if ((sockKlientow = accept(sockid, (struct sockaddr *)&thier_addr, &sin_size)) == -1)
	{
		perror("accept");
		continue;
	}
 	
	printf("SERWER: udało sie poloczyc z %s\n", inet_ntoa(thier_addr.sin_addr));
	if (!fork()) 
	{
		int koniec=0, i=0;
		char buf[64];
  		
		close(sockid); //nowy proces nie musi sluchac
		do
		{
			byteread = read(sockKlientow, buf, 64);
			for(i=0; i<byteread; i++) //w tej petli wyswietlam co napisal klient 
			{
				printf("%c", buf[i]);
			}
 			printf("\n");
			
			//sprawdzam jaki komunikat/rozkaz podano
			if((buf[0]=='e') && (buf[1]=='n') && (buf[2]=='d') && (buf[3]=='\0'))//rozkaz 'end' czyli rozlacz z serwerem
			{
				send(sockKlientow, "SERWER: zegnam", 14, 0);
				koniec=1;
			}
		
			for(i=0; i<byteread; i++) //czyszcze bufor
			{
				buf[i]='\0';
			}
		}while(koniec!=1);
		
		close(sockKlientow);
		exit(0);
	}
   close(sockKlientow);
 }
 return 0;
}
